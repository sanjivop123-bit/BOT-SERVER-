#!/usr/bin/env python3
"""One-command local runner (no Docker, no Postgres needed).

    pip install -r requirements.txt aiosqlite
    python run.py

Reads an optional .env file, fills in safe development defaults (SQLite, random SECRET_KEY / API key),
creates the tables, and starts the server at http://127.0.0.1:8080  (admin: /admin/login, health: /health).
Set ADMIN_PASSWORD (min 12 chars) to enable admin login; it is hashed with Argon2 at start.
For production use the Dockerfile / app.entrypoint (PostgreSQL + Alembic).
"""
from __future__ import annotations

import asyncio
import os
import secrets
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))


def load_dotenv(path: Path) -> None:
    if not path.is_file():
        return
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        os.environ.setdefault(key.strip(), value.strip().strip("'\""))


def main() -> None:
    load_dotenv(ROOT / ".env")
    env = os.environ
    env.setdefault("ENVIRONMENT", "development")
    env.setdefault("DATABASE_URL", f"sqlite+aiosqlite:///{ROOT / 'dev.db'}")
    env.setdefault("SECRET_KEY", secrets.token_urlsafe(48))
    if not env.get("API_KEYS"):
        env["API_KEYS"] = secrets.token_urlsafe(48)
        print(f"[run] generated temporary API key (X-API-Key): {env['API_KEYS']}")
    env.setdefault("ADMIN_USERNAME", "admin")
    if not env.get("ADMIN_PASSWORD_HASH") and env.get("ADMIN_PASSWORD"):
        from app.security import hash_password
        if len(env["ADMIN_PASSWORD"]) < 12:
            sys.exit("ADMIN_PASSWORD must be at least 12 characters")
        env["ADMIN_PASSWORD_HASH"] = hash_password(env["ADMIN_PASSWORD"])
    if not env.get("ADMIN_PASSWORD_HASH"):
        print("[run] no ADMIN_PASSWORD set: admin login disabled")

    try:
        import uvicorn
        from app.config import Settings
        from app.database import Database
        from app.main import create_app
    except ModuleNotFoundError as exc:
        sys.exit(f"Missing package '{exc.name}'. Run: pip install -r requirements.txt aiosqlite")

    settings = Settings.from_env()
    db = Database(settings)
    if settings.database_url.startswith("sqlite"):
        asyncio.run(db.create_all())  # dev only; Postgres uses Alembic
        asyncio.run(db.dispose())
    host = env.get("HOST", "127.0.0.1")
    port = int(env.get("PORT", "8080"))
    print(f"[run] http://{host}:{port}  (docs: /docs, health: /health)")
    uvicorn.run(create_app, factory=True, host=host, port=port, proxy_headers=True)


if __name__ == "__main__":
    main()
