# Deploy on Render

## Why your first deploy failed
Log: `failed to read dockerfile: open Dockerfile: no such file or directory`. Render looks for `Dockerfile` in the
repository ROOT, but the previous ZIP had everything inside a `HONESTY_AI_VIP_MASTER_FINAL/` folder. This ZIP has
no wrapper folder: unzip it and the files (`Dockerfile`, `app/`, `render.yaml` ...) are at the top level.

## Steps
1. Delete the old files in your GitHub repo (`PYTHON-SERVER-BOT`), then upload the **contents** of this ZIP so that
   `Dockerfile` is visible on the repo's first page (not inside a folder). On GitHub: Add file -> Upload files,
   drag the unzipped files and folders (include hidden files such as `.dockerignore`).
2. Create the admin hash on any computer with Python: `pip install argon2-cffi && python scripts/hash_password.py`
   (copy the line starting with `$argon2id$`).
3. Render -> New -> **Blueprint** -> select the repo. It creates the web service and a Postgres database from `render.yaml`.
   (Or create a Web Service manually: Language = Docker, Root Directory empty, Dockerfile path `./Dockerfile`, then add the variables below.)
4. When asked, fill: `ADMIN_PASSWORD_HASH`, and optionally `TELEGRAM_BOT_TOKEN`, `ADMIN_CHAT_IDS`, `MIN_DEPOSIT`.
   `SECRET_KEY` and `API_KEYS` are generated for you; open Environment to copy `API_KEYS` into your Telebot bot as `X-API-Key`.
5. Deploy. Check `https://YOUR-SERVICE.onrender.com/health` -> `{"status":"ok",...}` and `/admin/login`.

## Notes
- Migrations run automatically on every start (`alembic upgrade head`).
- `DATABASE_URL`: use Render's **Internal** database URL (the Blueprint does this). `postgresql://` is converted to
  asyncpg automatically. `?sslmode=...` in the URL is now translated for asyncpg automatically.
- Free web services sleep after inactivity (~50 s cold start); free Postgres expires after 30 days.
- Render provides HTTPS and sets `X-Forwarded-Proto`; the app's HTTPS-only mode works behind it.
- Verification returns `503 not_operational` until `OfficialAffiliateProvider` is implemented (see README).
- Not tested on Render from here: this fix was built without being able to run Docker or deploy.
