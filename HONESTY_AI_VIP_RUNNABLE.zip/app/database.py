"""Async database management (SQLAlchemy 2.x + asyncpg)."""
from __future__ import annotations

from typing import AsyncIterator
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from fastapi import Request
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.config import Settings
from app.models import Base


def normalize_database_url(url: str) -> str:
    if url.startswith("postgres://"):
        return "postgresql+asyncpg://" + url[len("postgres://"):]
    if url.startswith("postgresql://"):
        return "postgresql+asyncpg://" + url[len("postgresql://"):]
    return url


_SSL_MODES = {"disable": False, "allow": False, "prefer": False,
              "require": True, "verify-ca": True, "verify-full": True}


def split_connect_args(url: str) -> tuple[str, dict]:
    """asyncpg rejects libpq-style `sslmode=`/`sslrootcert=` query params that Render, Heroku and Cloud SQL
    URLs often carry. Strip them and translate sslmode into asyncpg's `ssl` connect argument."""
    parts = urlsplit(url)
    if not parts.query:
        return url, {}
    kept, connect_args = [], {}
    for key, value in parse_qsl(parts.query, keep_blank_values=True):
        if key == "sslmode":
            if _SSL_MODES.get(value, False):
                connect_args["ssl"] = True
        elif key in {"channel_binding", "sslrootcert", "sslcert", "sslkey"}:
            continue
        else:
            kept.append((key, value))
    return urlunsplit(parts._replace(query=urlencode(kept))), connect_args


class Database:
    def __init__(self, settings: Settings) -> None:
        url, connect_args = split_connect_args(normalize_database_url(settings.database_url))
        kwargs: dict = {"pool_pre_ping": True}
        if connect_args and not url.startswith("sqlite"):
            kwargs["connect_args"] = connect_args
        if url.startswith("sqlite"):
            from sqlalchemy.pool import StaticPool

            kwargs["poolclass"] = StaticPool  # in-memory DB shared by one connection (tests/dev)
        else:
            kwargs.update(
                pool_size=settings.db_pool_size,
                max_overflow=settings.db_max_overflow,
                pool_timeout=settings.db_pool_timeout,
                pool_recycle=1800,
            )
        self.engine = create_async_engine(url, **kwargs)
        self.session_factory = async_sessionmaker(self.engine, expire_on_commit=False)

    async def ping(self) -> bool:
        try:
            async with self.engine.connect() as conn:
                await conn.execute(text("SELECT 1"))
            return True
        except Exception:  # noqa: BLE001 - health check must never raise
            return False

    async def create_all(self) -> None:
        """For tests/local dev only. Production uses Alembic migrations."""
        async with self.engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)

    async def dispose(self) -> None:
        await self.engine.dispose()


async def get_session(request: Request) -> AsyncIterator[AsyncSession]:
    async with request.app.state.db.session_factory() as session:
        yield session
